package com.example.campusnavigator.models;

public class Building {
    private int buildingId;
    private String buildingName;
    private String buildingCode;
    private String description;
    private double latitude;
    private double longitude;
    private String operatingHours;
    private String contactInfo;

    public Building(int buildingId, String buildingName, String buildingCode, String description,
                    double latitude, double longitude, String operatingHours, String contactInfo) {
        this.buildingId = buildingId;
        this.buildingName = buildingName;
        this.buildingCode = buildingCode;
        this.description = description;
        this.latitude = latitude;
        this.longitude = longitude;
        this.operatingHours = operatingHours;
        this.contactInfo = contactInfo;
    }

    // Getters
    public int getBuildingId() { return buildingId; }
    public String getBuildingName() { return buildingName; }
    public String getBuildingCode() { return buildingCode; }
    public String getDescription() { return description; }
    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }
    public String getOperatingHours() { return operatingHours; }
    public String getContactInfo() { return contactInfo; }
}