package com.example.campusnavigator.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.example.campusnavigator.R;

public class MainActivity extends AppCompatActivity {
    private TextView tvWelcome;
    private LinearLayout cvMap, cvSearch, cvBuildings, cvAnnouncements, cvProfile;
    private String username, role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get user data from login
        username = getIntent().getStringExtra("username");
        role = getIntent().getStringExtra("role");

        if (username == null) username = "User";
        if (role == null) role = "Student";

        initializeViews();
        setupClickListeners();

        // Display welcome message with role
        tvWelcome.setText("Welcome, " + username + "!\n" + role);
    }

    private void initializeViews() {
        tvWelcome = findViewById(R.id.tvWelcome);
        cvMap = findViewById(R.id.cvMap);
        cvSearch = findViewById(R.id.cvSearch);
        cvBuildings = findViewById(R.id.cvBuildings);
        cvAnnouncements = findViewById(R.id.cvAnnouncements);
        cvProfile = findViewById(R.id.cvProfile);
    }

    private void setupClickListeners() {
        cvMap.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MapActivity.class);
            startActivity(intent);
        });

        cvSearch.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SearchActivity.class);
            startActivity(intent);
        });

        cvBuildings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, BuildingsActivity.class);
            startActivity(intent);
        });

        cvAnnouncements.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AnnouncementsActivity.class);
            startActivity(intent);
        });

        cvProfile.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            intent.putExtra("username", username);
            intent.putExtra("role", role);
            startActivity(intent);
        });
    }
}