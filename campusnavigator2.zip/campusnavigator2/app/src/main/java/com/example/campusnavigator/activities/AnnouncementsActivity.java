package com.example.campusnavigator.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.campusnavigator.R;
import com.example.campusnavigator.adapters.AnnouncementAdapter;
import com.example.campusnavigator.models.Announcement;
import java.util.ArrayList;
import java.util.List;

public class AnnouncementsActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private AnnouncementAdapter adapter;
    private List<Announcement> announcementList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcements);

        announcementList = new ArrayList<>();

        initializeViews();
        loadAnnouncements();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewAnnouncements);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new AnnouncementAdapter(announcementList);
        recyclerView.setAdapter(adapter);
    }

    private void loadAnnouncements() {
        announcementList.clear();

        // Sample announcements
        announcementList.add(new Announcement(1, "Maintenance Notice",
                "Science Building closed for maintenance until Nov 5.", "2024-10-25"));

        announcementList.add(new Announcement(2, "New Facility Opening",
                "Innovation Hub now open at ICT Building 3rd Floor.", "2024-10-20"));

        announcementList.add(new Announcement(3, "Library Hours Update",
                "Library extended hours during finals week: 7:00 AM - 10:00 PM", "2024-10-15"));

        announcementList.add(new Announcement(4, "Campus Wi-Fi Upgrade",
                "Campus-wide Wi-Fi upgrade scheduled for November 1-2. Intermittent connectivity expected.", "2024-10-10"));

        adapter.notifyDataSetChanged();
    }
}