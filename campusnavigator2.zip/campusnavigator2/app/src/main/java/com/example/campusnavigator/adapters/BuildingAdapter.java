package com.example.campusnavigator.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.campusnavigator.R;
import com.example.campusnavigator.models.Building;
import java.util.List;

public class BuildingAdapter extends RecyclerView.Adapter<BuildingAdapter.ViewHolder> {
    private List<Building> buildingList;

    public BuildingAdapter(List<Building> buildingList) {
        this.buildingList = buildingList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_building, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Building building = buildingList.get(position);

        holder.tvBuildingName.setText(building.getBuildingName());
        holder.tvBuildingCode.setText(building.getBuildingCode());
        holder.tvDescription.setText(building.getDescription());
        holder.tvOperatingHours.setText("Hours: " + building.getOperatingHours());
        holder.tvContact.setText("Contact: " + building.getContactInfo());
    }

    @Override
    public int getItemCount() {
        return buildingList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvBuildingName, tvBuildingCode, tvDescription, tvOperatingHours, tvContact;

        public ViewHolder(View view) {
            super(view);
            tvBuildingName = view.findViewById(R.id.tvBuildingName);
            tvBuildingCode = view.findViewById(R.id.tvBuildingCode);
            tvDescription = view.findViewById(R.id.tvDescription);
            tvOperatingHours = view.findViewById(R.id.tvOperatingHours);
            tvContact = view.findViewById(R.id.tvContact);
        }
    }
}