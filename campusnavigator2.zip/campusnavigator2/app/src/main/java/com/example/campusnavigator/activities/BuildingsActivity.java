package com.example.campusnavigator.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.campusnavigator.R;
import com.example.campusnavigator.adapters.BuildingAdapter;
import com.example.campusnavigator.models.Building;
import java.util.ArrayList;
import java.util.List;

public class BuildingsActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private BuildingAdapter adapter;
    private List<Building> buildingList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buildings);

        buildingList = new ArrayList<>();

        initializeViews();
        loadBuildings();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewBuildings);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new BuildingAdapter(buildingList);
        recyclerView.setAdapter(adapter);
    }

    private void loadBuildings() {
        buildingList.clear();

        // Sample buildings data
        buildingList.add(new Building(1, "CS Building", "BSCS",
                "Bachelor of Science in Computer Science",
                13.962982949195318, 121.1743054912759, "7:00 AM - 9:00 PM", "0912-345-6789"));

        buildingList.add(new Building(2, "ACT Building", "ACT",
                "Associate in Computer Technology",
                13.962974489592781, 121.17431018514158, "8:00 AM - 6:00 PM", "0912-345-6790"));

        buildingList.add(new Building(3, "Library", "Library Main Campus",
                "Library",
                13.962310347443154, 121.17459667456906,  "8:00 AM - 5:00 PM", "0912-345-6791"));

        buildingList.add(new Building(4, "Canteen", "Canteen",
                "Canteen Main Campus",
                14.6560, 121.0670, "7:00 AM - 8:00 PM", "0912-345-6792"));

        adapter.notifyDataSetChanged();
    }
}