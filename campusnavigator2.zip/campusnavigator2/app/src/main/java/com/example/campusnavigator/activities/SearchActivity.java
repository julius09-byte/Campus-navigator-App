package com.example.campusnavigator.activities;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.campusnavigator.R;

public class SearchActivity extends AppCompatActivity {
    private EditText etSearch;
    private ImageButton btnSearch;
    private TextView tvSearchResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        initializeViews();
        setupSearchListener();
    }

    private void initializeViews() {
        etSearch = findViewById(R.id.etSearch);
        btnSearch = findViewById(R.id.btnSearch);
        tvSearchResult = findViewById(R.id.tvSearchResult);
    }

    private void setupSearchListener() {
        btnSearch.setOnClickListener(v -> performSearch());
    }

    private void performSearch() {
        String query = etSearch.getText().toString().trim();

        if (query.isEmpty()) {
            Toast.makeText(this, "Please enter a search term", Toast.LENGTH_SHORT).show();
            return;
        }

        // Sample search results
        if (query.toLowerCase().contains("registrar") || query.toLowerCase().contains("office")) {
            tvSearchResult.setText("📍 Registrar's Office\n" +
                    "🏛️ Located at Admin Building, Ground Floor\n" +
                    "🕒 Open Hours: 8:00 AM - 5:00 PM\n" +
                    "🚶 3-minute walk from Main Gate\n" +
                    "☎️ Contact: 0912-345-6791");
        } else if (query.toLowerCase().contains("library")) {
            tvSearchResult.setText("📍 Library Building (LIB)\n" +
                    "🏛️ Main Campus Library\n" +
                    "🕒 Open Hours: 8:00 AM - 6:00 PM\n" +
                    "🚶 5-minute walk from Main Gate\n" +
                    "☎️ Contact: 0912-345-6790");
        } else if (query.toLowerCase().contains("ict") || query.toLowerCase().contains("computer")) {
            tvSearchResult.setText("📍 ICT Building\n" +
                    "🏛️ Information and Communication Technology Building\n" +
                    "🕒 Open Hours: 7:00 AM - 9:00 PM\n" +
                    "🚶 2-minute walk from Main Gate\n" +
                    "☎️ Contact: 0912-345-6789");
        } else {
            tvSearchResult.setText("❌ No results found for: " + query +
                    "\n\nTry searching for:\n• Registrar's Office\n• Library\n• ICT Building\n• Science Building");
        }
    }
}