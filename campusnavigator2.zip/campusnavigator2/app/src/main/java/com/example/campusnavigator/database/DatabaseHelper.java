package com.example.campusnavigator.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.campusnavigator.models.User;
import com.example.campusnavigator.models.Building;
import com.example.campusnavigator.models.Announcement;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "CampusNavigator.db";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_ROLE = "role";
    private static final String COLUMN_DEPARTMENT = "department";

    // Buildings Table
    private static final String TABLE_BUILDINGS = "buildings";
    private static final String COLUMN_BUILDING_ID = "building_id";
    private static final String COLUMN_BUILDING_NAME = "building_name";
    private static final String COLUMN_BUILDING_CODE = "building_code";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_LATITUDE = "latitude";
    private static final String COLUMN_LONGITUDE = "longitude";
    private static final String COLUMN_OPERATING_HOURS = "operating_hours";
    private static final String COLUMN_CONTACT_INFO = "contact_info";

    // Announcements Table
    private static final String TABLE_ANNOUNCEMENTS = "announcements";
    private static final String COLUMN_ANNOUNCEMENT_ID = "announcement_id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_MESSAGE = "message";
    private static final String COLUMN_DATE = "date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT UNIQUE,"
                + COLUMN_PASSWORD + " TEXT,"
                + COLUMN_NAME + " TEXT,"
                + COLUMN_ROLE + " TEXT,"
                + COLUMN_DEPARTMENT + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        // Create Buildings Table
        String CREATE_BUILDINGS_TABLE = "CREATE TABLE " + TABLE_BUILDINGS + "("
                + COLUMN_BUILDING_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_BUILDING_NAME + " TEXT,"
                + COLUMN_BUILDING_CODE + " TEXT,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_LATITUDE + " REAL,"
                + COLUMN_LONGITUDE + " REAL,"
                + COLUMN_OPERATING_HOURS + " TEXT,"
                + COLUMN_CONTACT_INFO + " TEXT" + ")";
        db.execSQL(CREATE_BUILDINGS_TABLE);

        // Create Announcements Table
        String CREATE_ANNOUNCEMENTS_TABLE = "CREATE TABLE " + TABLE_ANNOUNCEMENTS + "("
                + COLUMN_ANNOUNCEMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TITLE + " TEXT,"
                + COLUMN_MESSAGE + " TEXT,"
                + COLUMN_DATE + " TEXT" + ")";
        db.execSQL(CREATE_ANNOUNCEMENTS_TABLE);

        // Insert sample data
        insertSampleData(db);
    }

    private void insertSampleData(SQLiteDatabase db) {
        // Insert sample users
        ContentValues user1 = new ContentValues();
        user1.put(COLUMN_USERNAME, "miguel");
        user1.put(COLUMN_PASSWORD, "password123");
        user1.put(COLUMN_NAME, "Miguel Santos");
        user1.put(COLUMN_ROLE, "1st-Year BSIT Student");
        user1.put(COLUMN_DEPARTMENT, "College of IT");
        db.insert(TABLE_USERS, null, user1);

        ContentValues user2 = new ContentValues();
        user2.put(COLUMN_USERNAME, "admin");
        user2.put(COLUMN_PASSWORD, "admin123");
        user2.put(COLUMN_NAME, "Administrator");
        user2.put(COLUMN_ROLE, "System Administrator");
        user2.put(COLUMN_DEPARTMENT, "IT Department");
        db.insert(TABLE_USERS, null, user2);

        ContentValues user3 = new ContentValues();
        user3.put(COLUMN_USERNAME, "maria");
        user3.put(COLUMN_PASSWORD, "maria2024");
        user3.put(COLUMN_NAME, "Maria Garcia");
        user3.put(COLUMN_ROLE, "2nd-Year Engineering Student");
        user3.put(COLUMN_DEPARTMENT, "College of Engineering");
        db.insert(TABLE_USERS, null, user3);

        ContentValues user4 = new ContentValues();
        user4.put(COLUMN_USERNAME, "professor");
        user4.put(COLUMN_PASSWORD, "teach123");
        user4.put(COLUMN_NAME, "Dr. Robert Lim");
        user4.put(COLUMN_ROLE, "Faculty Member");
        user4.put(COLUMN_DEPARTMENT, "Computer Science Department");
        db.insert(TABLE_USERS, null, user4);

        // Insert sample buildings
        ContentValues building1 = new ContentValues();
        building1.put(COLUMN_BUILDING_NAME, "ACT Building");
        building1.put(COLUMN_BUILDING_CODE, "ACT");
        building1.put(COLUMN_DESCRIPTION, "Associate in Computer Technology");
        building1.put(COLUMN_LATITUDE, 13.962974489592781);
        building1.put(COLUMN_LONGITUDE, 121.17431018514158);
        building1.put(COLUMN_OPERATING_HOURS, "7:00 AM - 9:00 PM");
        building1.put(COLUMN_CONTACT_INFO, "0912-345-6789");
        db.insert(TABLE_BUILDINGS, null, building1);

        ContentValues building2 = new ContentValues();
        building2.put(COLUMN_BUILDING_NAME, "Library");
        building2.put(COLUMN_BUILDING_CODE, "LIB");
        building2.put(COLUMN_DESCRIPTION, "Main Campus Library");
        building2.put(COLUMN_LATITUDE, 14.6550);
        building2.put(COLUMN_LONGITUDE, 121.0680);
        building2.put(COLUMN_OPERATING_HOURS, "8:00 AM - 6:00 PM");
        building2.put(COLUMN_CONTACT_INFO, "0912-345-6790");
        db.insert(TABLE_BUILDINGS, null, building2);

        ContentValues building3 = new ContentValues();
        building3.put(COLUMN_BUILDING_NAME, "Administration Building");
        building3.put(COLUMN_BUILDING_CODE, "ADMIN");
        building3.put(COLUMN_DESCRIPTION, "Main Administration Office");
        building3.put(COLUMN_LATITUDE, 14.6535);
        building3.put(COLUMN_LONGITUDE, 121.0665);
        building3.put(COLUMN_OPERATING_HOURS, "8:00 AM - 5:00 PM");
        building3.put(COLUMN_CONTACT_INFO, "0912-345-6791");
        db.insert(TABLE_BUILDINGS, null, building3);

        ContentValues building4 = new ContentValues();
        building4.put(COLUMN_BUILDING_NAME, "BSCS Building");
        building4.put(COLUMN_BUILDING_CODE, "BSCS");
        building4.put(COLUMN_DESCRIPTION, "Bachelor of Science in Computer Science");
        building4.put(COLUMN_LATITUDE, 13.962982949195318);
        building4.put(COLUMN_LONGITUDE, 121.1743054912759);
        building4.put(COLUMN_OPERATING_HOURS, "7:00 AM - 8:00 PM");
        building4.put(COLUMN_CONTACT_INFO, "0912-345-6792");
        db.insert(TABLE_BUILDINGS, null, building4);

        // Insert sample announcements
        ContentValues announcement1 = new ContentValues();
        announcement1.put(COLUMN_TITLE, "Maintenance Notice");
        announcement1.put(COLUMN_MESSAGE, "Science Building closed for maintenance until Nov 5.");
        announcement1.put(COLUMN_DATE, "2024-10-25");
        db.insert(TABLE_ANNOUNCEMENTS, null, announcement1);

        ContentValues announcement2 = new ContentValues();
        announcement2.put(COLUMN_TITLE, "New Facility Opening");
        announcement2.put(COLUMN_MESSAGE, "Innovation Hub now open at ICT Building 3rd Floor.");
        announcement2.put(COLUMN_DATE, "2024-10-20");
        db.insert(TABLE_ANNOUNCEMENTS, null, announcement2);

        ContentValues announcement3 = new ContentValues();
        announcement3.put(COLUMN_TITLE, "Library Hours Update");
        announcement3.put(COLUMN_MESSAGE, "Library extended hours during finals week: 7:00 AM - 10:00 PM");
        announcement3.put(COLUMN_DATE, "2024-10-15");
        db.insert(TABLE_ANNOUNCEMENTS, null, announcement3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BUILDINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ANNOUNCEMENTS);
        onCreate(db);
    }

    // ========== USER REGISTRATION METHODS ==========

    /**
     * Register a new user
     */
    public boolean registerUser(String username, String password, String name, String role, String department) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if username already exists
        if (isUsernameExists(username)) {
            return false; // Username already taken
        }

        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_ROLE, role);
        values.put(COLUMN_DEPARTMENT, department);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    /**
     * Check if username already exists
     */
    public boolean isUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Check user credentials for login
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    /**
     * Get user details by username
     */
    public User getUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        User user = null;
        if (cursor.moveToFirst()) {
            user = new User(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USERNAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ROLE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DEPARTMENT))
            );
        }
        cursor.close();
        return user;
    }

    /**
     * Get all users (for admin purposes)
     */
    public Cursor getAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS, null);
    }

    /**
     * Update user profile
     */
    public boolean updateUser(String username, String name, String role, String department) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_ROLE, role);
        values.put(COLUMN_DEPARTMENT, department);

        int result = db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", new String[]{username});
        return result > 0;
    }

    /**
     * Change user password
     */
    public boolean changePassword(String username, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, newPassword);

        int result = db.update(TABLE_USERS, values, COLUMN_USERNAME + " = ?", new String[]{username});
        return result > 0;
    }

    /**
     * Delete user account
     */
    public boolean deleteUser(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_USERS, COLUMN_USERNAME + " = ?", new String[]{username});
        return result > 0;
    }

    // ========== BUILDING METHODS ==========

    /**
     * Get all buildings
     */
    public Cursor getAllBuildings() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_BUILDINGS, null);
    }

    /**
     * Search buildings by name or code
     */
    public Cursor searchBuildings(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        String searchQuery = "SELECT * FROM " + TABLE_BUILDINGS +
                " WHERE " + COLUMN_BUILDING_NAME + " LIKE ? OR " +
                COLUMN_BUILDING_CODE + " LIKE ?";
        return db.rawQuery(searchQuery, new String[]{"%" + query + "%", "%" + query + "%"});
    }

    /**
     * Add new building (admin function)
     */
    public boolean addBuilding(String name, String code, String description,
                               double latitude, double longitude, String hours, String contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_BUILDING_NAME, name);
        values.put(COLUMN_BUILDING_CODE, code);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_LATITUDE, latitude);
        values.put(COLUMN_LONGITUDE, longitude);
        values.put(COLUMN_OPERATING_HOURS, hours);
        values.put(COLUMN_CONTACT_INFO, contact);

        long result = db.insert(TABLE_BUILDINGS, null, values);
        return result != -1;
    }

    // ========== ANNOUNCEMENT METHODS ==========

    /**
     * Get all announcements
     */
    public Cursor getAllAnnouncements() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_ANNOUNCEMENTS + " ORDER BY " + COLUMN_DATE + " DESC", null);
    }

    /**
     * Add new announcement (admin function)
     */
    public boolean addAnnouncement(String title, String message, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_MESSAGE, message);
        values.put(COLUMN_DATE, date);

        long result = db.insert(TABLE_ANNOUNCEMENTS, null, values);
        return result != -1;
    }

    /**
     * Get latest announcements
     */
    public Cursor getLatestAnnouncements(int limit) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_ANNOUNCEMENTS +
                " ORDER BY " + COLUMN_DATE + " DESC LIMIT " + limit, null);
    }
}