package com.example.campusnavigator.models;

public class Announcement {
    private int announcementId;
    private String title;
    private String message;
    private String date;

    public Announcement(int announcementId, String title, String message, String date) {
        this.announcementId = announcementId;
        this.title = title;
        this.message = message;
        this.date = date;
    }

    // Getters
    public int getAnnouncementId() { return announcementId; }
    public String getTitle() { return title; }
    public String getMessage() { return message; }
    public String getDate() { return date; }
}