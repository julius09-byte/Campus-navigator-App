package com.example.campusnavigator.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.campusnavigator.R;
import com.example.campusnavigator.activities.LoginActivity;

public class ProfileActivity extends AppCompatActivity {
    private TextView tvName, tvRole, tvDepartment, tvUsername;
    private Button btnLogout;
    private String username, role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Get user data from MainActivity
        username = getIntent().getStringExtra("username");
        role = getIntent().getStringExtra("role");

        initializeViews();
        setupLogoutButton();
        loadUserProfile(username, role);
    }

    private void initializeViews() {
        tvName = findViewById(R.id.tvName);
        tvRole = findViewById(R.id.tvRole);
        tvDepartment = findViewById(R.id.tvDepartment);
        tvUsername = findViewById(R.id.tvUsername);
        btnLogout = findViewById(R.id.btnLogout);
    }

    private void setupLogoutButton() {
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLogoutConfirmationDialog();
            }
        });
    }

    private void showLogoutConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                performLogout();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void performLogout() {
        // Clear any session data if you have
        // For example, if you're using SharedPreferences:
        // SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        // prefs.edit().clear().apply();

        // Navigate to LoginActivity and clear back stack
        Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();

        // Also finish the MainActivity if needed
        // This prevents going back to MainActivity after logout
    }

    private void loadUserProfile(String username, String role) {
        if (username == null) username = "User";
        if (role == null) role = "Student";

        switch (username) {
            case "miguel":
                tvName.setText("Miguel Santos");
                tvRole.setText("1st-Year BSIT Student");
                tvDepartment.setText("College of Information Technology");
                tvUsername.setText("miguel");
                break;
            case "admin":
                tvName.setText("Administrator");
                tvRole.setText("System Administrator");
                tvDepartment.setText("IT Department");
                tvUsername.setText("admin");
                break;
            case "maria":
                tvName.setText("Maria Garcia");
                tvRole.setText("2nd-Year Engineering Student");
                tvDepartment.setText("College of Engineering");
                tvUsername.setText("maria");
                break;
            case "professor":
                tvName.setText("Dr. Robert Lim");
                tvRole.setText("Faculty Member");
                tvDepartment.setText("Computer Science Department");
                tvUsername.setText("professor");
                break;
            default:
                tvName.setText(username);
                tvRole.setText(role);
                tvDepartment.setText("Not specified");
                tvUsername.setText(username);
        }
    }

    @Override
    public void onBackPressed() {
        // Go back to MainActivity when back button is pressed
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("username", username);
        intent.putExtra("role", role);
        startActivity(intent);
        finish();
    }
}