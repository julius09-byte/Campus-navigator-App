package com.example.campusnavigator.activities;

import android.os.Bundle;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.example.campusnavigator.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    private FrameLayout mapContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        mapContainer = findViewById(R.id.mapContainer);

        // Initialize Google Maps
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Sample campus location (adjust to your campus coordinates)
        LatLng campusCenter = new LatLng(13.962995563723403, 121.17421839340783);

        // Add markers for sample buildings
        LatLng bscsBuilding = new LatLng(13.962982949195318, 121.1743054912759);
        LatLng actBuiding = new LatLng(13.962974489592781, 121.17431018514158);
        LatLng library = new LatLng(13.962310347443154, 121.17459667456906);
        LatLng canteen = new LatLng(13.962694766769447, 121.17464906743237);



        mMap.addMarker(new MarkerOptions()
                .position(bscsBuilding)
                .title("BSCS Building")
                .snippet("Bachelor of Science in Computer Science"));

        mMap.addMarker(new MarkerOptions()
                .position(actBuiding)
                .title("ACT Building")
                .snippet("Associate in Computer Technology"));

        mMap.addMarker(new MarkerOptions()
                .position(campusCenter)
                .title("Campus Center")
                .snippet("Sample Campus Location"));

        mMap.addMarker(new MarkerOptions()
                .position(library)
                .title("Library Main Campus")
                .snippet("Library Main"));

        mMap.addMarker(new MarkerOptions()
                .position(canteen)
                .title("Canteen")
                .snippet("Canteen"));




        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(campusCenter, 16));
    }
}